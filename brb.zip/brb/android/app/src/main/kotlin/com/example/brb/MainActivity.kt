package com.example.brb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
