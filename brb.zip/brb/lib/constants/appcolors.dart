import 'package:flutter/animation.dart';

class AppColors {
  static const primaryColor = Color(0XFF0E4004);
  static const appBackgroundColor = Color(0xffDEE6AA);
    static const yellowColor = Color(0xffFFC000);

}
