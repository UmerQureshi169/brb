import 'package:flutter/cupertino.dart';

class AppPadding {
  static const defaultPadding = EdgeInsets.only(left: 25, right: 25);
  static const defaultPaddingList =
      EdgeInsets.only(top: 20, left: 25, right: 25, bottom: 12);
}
